import os
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    TimerAction,
)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_nav = get_package_share_directory('agv_mecanum_navigation')
    nav2_bringup_dir = get_package_share_directory('nav2_bringup')

    params_file = os.path.join(pkg_nav, 'config', 'nav2.yaml')
    slam_params = os.path.join(pkg_nav, 'config', 'slam.yaml')
    rviz_config = os.path.join(pkg_nav, 'rviz', 'nav_config.rviz')
    default_map = os.path.join(pkg_nav, 'maps', 'warehouse_map.yaml')

    map_yaml = LaunchConfiguration('map', default=default_map)
    use_slam = LaunchConfiguration('use_slam', default='false')

    # Nav2 navigation stack (controller, planner, behavior, bt_navigator)
    nav2 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(nav2_bringup_dir, 'launch', 'navigation_launch.py')
        ),
        launch_arguments={
            'params_file': params_file,
            'map': map_yaml,
            'use_sim_time': 'true',
        }.items(),
    )

    # map_server — loads the pre-built map
    map_server = Node(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        parameters=[
            {'use_sim_time': True},
            {'yaml_filename': map_yaml},
        ],
    )

    # AMCL — localizes the robot using the pre-built map
    amcl = Node(
        package='nav2_amcl',
        executable='amcl',
        name='amcl',
        output='screen',
        parameters=[
            params_file,
            {'use_sim_time': True},
        ],
    )

    # Lifecycle manager for map_server + AMCL
    lifecycle_localization = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_localization',
        output='screen',
        parameters=[
            {'use_sim_time': True},
            {'autostart': True},
            {'node_names': ['map_server', 'amcl']},
        ],
    )

    # SLAM Toolbox — alternative to AMCL when building map
    slam = Node(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        output='screen',
        parameters=[
            slam_params,
            {'use_sim_time': True},
        ],
        condition=IfCondition(use_slam),
    )

    # RViz2
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_config],
        output='screen',
    )

    delayed_lifecycle = TimerAction(period=5.0, actions=[lifecycle_localization])
    delayed_nav2 = TimerAction(period=6.0, actions=[nav2])
    delayed_rviz = TimerAction(period=3.0, actions=[rviz])

    return LaunchDescription([
        DeclareLaunchArgument('map', default_value=default_map),
        DeclareLaunchArgument('use_slam', default_value='false'),
        DeclareLaunchArgument('use_sim_time', default_value='true'),

        # Localization (map_server + AMCL) — activated by lifecycle manager
        map_server,
        amcl,
        delayed_lifecycle,
        # Nav2 stack
        delayed_nav2,
        # SLAM (alternative to AMCL)
        slam,
        delayed_rviz,
    ])
