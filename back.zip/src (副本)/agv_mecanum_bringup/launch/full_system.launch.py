import os
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    TimerAction,
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_gazebo = get_package_share_directory('agv_mecanum_gazebo')
    pkg_nav = get_package_share_directory('agv_mecanum_navigation')

    # 1. Gazebo simulation (includes: Gazebo + spawn + bridge + controller spawners)
    gazebo_sim = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo, 'launch', 'gazebo.launch.py')
        ),
    )

    # 2. Navigation stack (Nav2 + SLAM + RViz), delayed for Gazebo init
    navigation = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_nav, 'launch', 'full_navigation.launch.py')
        ),
        launch_arguments={
            'map': LaunchConfiguration('map', default=''),
        }.items(),
    )

    # Delay navigation by 8 seconds to ensure:
    # - Gazebo fully loaded
    # - Robot spawned
    # - ros2_control controllers active
    # - mecanum_drive_controller producing odometry
    delayed_navigation = TimerAction(period=8.0, actions=[navigation])

    return LaunchDescription([
        DeclareLaunchArgument('map', default_value=''),
        gazebo_sim,
        delayed_navigation,
    ])
