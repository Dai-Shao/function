import os
from launch import LaunchDescription
from launch.actions import (
    IncludeLaunchDescription,
    SetEnvironmentVariable,
    TimerAction,
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_description = get_package_share_directory('agv_mecanum_description')
    pkg_gazebo = get_package_share_directory('agv_mecanum_gazebo')

    world_path = os.path.join(pkg_gazebo, 'worlds', 'warehouse.world')
    urdf_path = os.path.join(pkg_description, 'urdf', 'agv_mecanum.urdf.xacro')

    # Process xacro
    robot_description = ParameterValue(
        Command(['xacro ', urdf_path, ' use_gazebo:=true']),
        value_type=str
    )

    # 1. Gazebo Harmonic (server + client GUI)
    gz_sim = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('ros_gz_sim'),
                'launch', 'gz_sim.launch.py'
            )
        ),
        launch_arguments={
            'gz_args': ['-r ', world_path],
            'on_exit_shutdown': 'true',
        }.items(),
    )

    # 2. Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{
            'robot_description': robot_description,
            'use_sim_time': True,
        }],
    )

    # 3. Spawn robot in Gazebo
    spawn_robot = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-name', 'agv_mecanum',
            '-topic', 'robot_description',
            '-x', '0',
            '-y', '0',
            '-z', '0.05',
        ],
        output='screen',
    )

    # 4. ROS-Gazebo bridges
    bridge_clock = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'],
        output='screen',
    )

    bridge_scan = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/scan@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan'],
        output='screen',
    )

    bridge_imu = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/imu@sensor_msgs/msg/Imu[gz.msgs.IMU'],
        output='screen',
    )

    # 5. Static TF: map → odom (needed for Nav2 before SLAM publishes it)
    static_map_odom = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom'],
        output='screen',
    )

    # 6. Relay: controller TF → standard /tf topic
    # mecanum_drive_controller publishes TF to ~/tf_odometry, not /tf
    relay_tf = Node(
        package='agv_mecanum_gazebo',
        executable='tf_relay.py',
        output='screen',
        parameters=[{'use_sim_time': True}],
    )

    # 7. Controller spawners (delayed for Gazebo init)
    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '-c', '/controller_manager'],
        output='screen',
    )

    mecanum_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['mecanum_drive_controller', '-c', '/controller_manager'],
        output='screen',
    )

    # 8. Drive demo — drives in a square pattern after controllers are ready
    drive_demo = Node(
        package='agv_mecanum_gazebo',
        executable='drive_demo.py',
        output='screen',
    )

    delayed_spawners = TimerAction(
        period=5.0,
        actions=[
            joint_state_broadcaster_spawner,
            TimerAction(
                period=2.0,
                actions=[mecanum_controller_spawner],
            ),
            TimerAction(
                period=3.0,
                actions=[relay_tf],
            ),
            TimerAction(
                period=5.0,
                actions=[drive_demo],
            ),
        ],
    )

    return LaunchDescription([
        # Force Intel iris Mesa driver for Ogre2 rendering
        SetEnvironmentVariable('MESA_LOADER_DRIVER_OVERRIDE', 'iris'),
        SetEnvironmentVariable('LIBGL_DRI3_DISABLE', '1'),
        gz_sim,
        robot_state_publisher,
        spawn_robot,
        bridge_clock,
        bridge_scan,
        bridge_imu,
        static_map_odom,
        delayed_spawners,
    ])
